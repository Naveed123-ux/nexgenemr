import smtplib
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from dotenv import load_dotenv

load_dotenv()

def _send_email(recipient_email, subject, body):
    email_user = os.getenv("EMAIL_USER")
    email_pass = os.getenv("EMAIL_PASS")

    if not email_user or not email_pass:
        print("WARNING: Email credentials not found in .env. Cannot send email.")
        return False

    message = MIMEMultipart()
    message["From"] = email_user
    message["To"] = recipient_email
    message["Subject"] = subject
    message.attach(MIMEText(body, "plain"))

    try:
        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(email_user, email_pass)
        server.sendmail(email_user, recipient_email, message.as_string())
        server.quit()
        print(f"Successfully sent email to {recipient_email}")
        return True
    except Exception as e:
        print(f"ERROR: Failed to send email to {recipient_email}. Error: {e}")
        return False

def send_welcome_email(recipient_email: str, temporary_password: str):
    subject = "Welcome to EMR - Your Account Details"
    body = f"""
    Hello,
    An account has been created for you for the EMR system.
    You can log in using the following credentials:
    Email: {recipient_email}
    Temporary Password: {temporary_password}
    It is highly recommended that you change your password upon your first login.
    Thank you,
    The EMR Team
    """
    _send_email(recipient_email, subject, body)

def send_appointment_confirmation_email(
    recipient_email: str, 
    patient_name: str, 
    doctor_name: str, 
    appointment_time: str, 
    is_telehealth: bool, 
    meet_link: str = None, 
    hospital_address: str = None
):
    subject = "Your Appointment is Confirmed"
    
    if is_telehealth:
        body = f"""
        Hello {patient_name},

        This email confirms your telehealth appointment with {doctor_name} on {appointment_time}.

        Please log in to the patient portal shortly before your appointment to join the video call.
        Google Meet Link: {meet_link}

        Thank you,
        The EMR Team
        """
    else:
        body = f"""
        Hello {patient_name},

        This email confirms your in-person appointment with {doctor_name} on {appointment_time}.

        Please arrive 15 minutes early for your appointment.
        Location: {hospital_address}

        Thank you,
        The EMR Team
        """
    _send_email(recipient_email, subject, body)
