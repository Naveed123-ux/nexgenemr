import logging
import os
import seqlog
import requests
import time
from dotenv import load_dotenv
from requests.exceptions import ConnectionError

load_dotenv()

def setup_audit_logging():
    seq_server_url = os.getenv("SEQ_SERVER_URL")
    seq_api_key = os.getenv("SEQ_API_KEY")

    logger = logging.getLogger("audit")
    logger.setLevel(logging.INFO)

    if not seq_server_url:
        print("WARNING: SEQ_SERVER_URL not found in .env. Using standard audit logger.")
        return logger

    max_retries = 5
    retry_delay = 2
    for attempt in range(max_retries):
        try:
            response = requests.get(seq_server_url, timeout=3)
            if response.status_code == 200:
                print("Seq server is responsive. Proceeding with logger configuration.")
                break
        except ConnectionError:
            pass

        if attempt < max_retries - 1:
            print(f"Seq server not ready. Retrying in {retry_delay} seconds... ({attempt + 1}/{max_retries})")
            time.sleep(retry_delay)
        else:
            print(f"WARNING: Could not connect to Seq at {seq_server_url}. Using standard audit logger.")
            return logger

    try:
        seqlog.log_to_seq(
            server_url=seq_server_url,
            api_key=seq_api_key,
            level=logging.INFO,
            batch_size=10,
            auto_flush_timeout=10,
            override_root_logger=False
        )
        print("Audit logger configured to send logs to Seq.")
        return logger
    except Exception as e:
        print(f"WARNING: Error configuring Seq logger. Using standard audit logger. Error: {e}")
        return logger

# Initialize the logger when the module is loaded
audit_logger = setup_audit_logging()
