from fastapi import Depends, HTTPException, status
from sqlalchemy.orm import Session
from models.user_model import User
from models.role_model import Role
from pydantic import BaseModel, EmailStr
from typing import List, Optional
from db.db import get_db
from datetime import datetime
from utils.encryption import encrypt_field
from utils.jwt import create_access_token, create_refresh_token
from passlib.context import CryptContext

# Setup for password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password):
    return pwd_context.hash(password)

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    first_name: str
    last_name: str
    role_id: int
    is_active: bool = True

class UserResponse(BaseModel):
    id: int
    email: EmailStr
    first_name: str
    last_name: str
    role_id: int
    is_active: bool
    created_at: str
    updated_at: str

    class Config:
        from_attributes = True

class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    user_id: int
    email: EmailStr
    role: str
    # --- Added first_name and last_name ---
    first_name: str
    last_name: str

class RoleResponse(BaseModel):
    role: str

def authenticate_user(email: str, password: str, db: Session) -> Optional[User]:
    users = db.query(User).all()
    for user in users:
        if user.email == email:
            if verify_password(password, user.hashed_password):
                return user
    return None

def login_for_access_token(login_data: LoginRequest, db: Session):
    user = authenticate_user(login_data.email, login_data.password, db)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect email or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    token_data = {"sub": user.email, "role": user.role.name}
    access_token = create_access_token(data=token_data)
    refresh_token = create_refresh_token(data=token_data)
    
    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        user_id=user.id,
        email=user.email,
        role=user.role.name,
        # --- Pass the user's name in the response ---
        first_name=user.first_name,
        last_name=user.last_name
    )

def create_user(user: UserCreate, db: Session = Depends(get_db)):
    # ... (create user logic remains the same) ...
    role = db.query(Role).filter(Role.id == user.role_id).first()
    if not role:
        raise HTTPException(status_code=404, detail=f"Role with id {user.role_id} not found")
    all_users = db.query(User).all()
    for existing_user in all_users:
        if existing_user.email == user.email:
            raise HTTPException(status_code=400, detail="Email already registered")
    hashed_password = get_password_hash(user.password)
    now_str = str(datetime.utcnow())
    db_user = User(
        email=user.email,
        hashed_password=hashed_password,
        first_name=user.first_name,
        last_name=user.last_name,
        role_id=user.role_id,
        is_active=user.is_active,
        created_at=now_str,
        updated_at=now_str
    )
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    return db_user


def get_users(db: Session = Depends(get_db)) -> List[UserResponse]:
    return db.query(User).all()

def get_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return user

def get_user_role(current_user: User) -> RoleResponse:
    if not current_user.role:
        raise HTTPException(status_code=404, detail="User role not found.")
    return RoleResponse(role=current_user.role.name)
