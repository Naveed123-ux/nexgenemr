import secrets
import string
from fastapi import Depends, HTTPException, UploadFile
from sqlalchemy.orm import Session , joinedload
import math
from pydantic import BaseModel, EmailStr
from datetime import datetime
from typing import List, Optional

from db.db import get_db
from models.hospital_model import Hospital
from models.user_model import User
from models.role_model import Role
from services.user_service import get_password_hash
from utils.email_utils import send_welcome_email
from utils.cloudinary_utils import upload_image

class HospitalCreate(BaseModel):
    # Basic Info
    name: str
    code: str
    email: EmailStr
    phone_number: str
    country: str
    address: str
    time_zone: str
    primary_language: str
    admin_first_name: str
    admin_last_name: str
    # Branding Info
    header_text: str
    tagline: str
    description: str
    sidebar_color: str
    header_color: str

class HospitalResponse(BaseModel):
    id: int
    name: str
    code: str
    email: EmailStr
    admin_user_id: int

    class Config:
        from_attributes = True

class HospitalDetailsResponse(BaseModel):
    id: int
    name: str
    code: str
    email: EmailStr
    phone_number: Optional[str]
    country: Optional[str]
    address: Optional[str]
    time_zone: Optional[str]
    primary_language: Optional[str]
    header_text: Optional[str]
    tagline: Optional[str]
    description: Optional[str]
    logo_url: Optional[str]
    favicon_url: Optional[str]
    sidebar_color: Optional[str]
    header_color: Optional[str]
    admin_user_id: int

    class Config:
        from_attributes = True

# Response model for paginated data
class PaginatedHospitalResponse(BaseModel):
    total: int
    page: int
    size: int
    totalPages: int
    hospitals: List[HospitalDetailsResponse]

# Simple data structure for internal use
class PaginatedData:
    def __init__(self, total: int, page: int, size: int, totalPages: int, hospitals: List):
        self.total = total
        self.page = page
        self.size = size
        self.totalPages = totalPages
        self.hospitals = hospitals

def generate_temporary_password(length=12):
    """Generates a secure, random password."""
    alphabet = string.ascii_letters + string.digits + string.punctuation
    return ''.join(secrets.choice(alphabet) for i in range(length))

def create_hospital_and_admin(
    db: Session,
    hospital_data: HospitalCreate,
    logo: UploadFile,
    favicon: UploadFile
):
    db.begin_nested()
    try:
        logo_url = upload_image(file=logo, required_format='png', max_size_kb=1024, required_dims=(255, 255))
        favicon_url = upload_image(file=favicon, required_format='png', max_size_kb=512, required_dims=(32, 32))

        all_roles = db.query(Role).all()
        admin_role = next((role for role in all_roles if role.name == "Hospital_Admin"), None)
        if not admin_role:
            raise HTTPException(status_code=500, detail="The 'Hospital_Admin' role has not been configured.")

        all_users = db.query(User).all()
        if any(user.email == hospital_data.email for user in all_users):
            raise HTTPException(status_code=400, detail="A user with this email already exists.")

        temp_password = generate_temporary_password()
        admin_user = User(
            email=hospital_data.email,
            hashed_password=get_password_hash(temp_password),
            first_name=hospital_data.admin_first_name,
            last_name=hospital_data.admin_last_name,
            role_id=admin_role.id,
            created_at=str(datetime.utcnow()),
            updated_at=str(datetime.utcnow())
        )
        db.add(admin_user)
        db.flush()

        new_hospital = Hospital(
            **hospital_data.dict(),
            logo_url=logo_url,
            favicon_url=favicon_url,
            admin_user_id=admin_user.id
        )
        db.add(new_hospital)
       
        send_welcome_email(hospital_data.email, temp_password)

        db.commit()
        return new_hospital

    except Exception as e:
        db.rollback()
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {str(e)}")

def get_hospital_by_id(hospital_id: int, current_user: User, db: Session):
    hospital = db.query(Hospital).filter(Hospital.id == hospital_id).first()

    if not hospital:
        raise HTTPException(status_code=404, detail="Hospital not found.")

    user_role = current_user.role.name
    if user_role == "Super_Admin":
        return hospital
   
    if user_role == "Hospital_Admin" and current_user.hospital and current_user.hospital.id == hospital_id:
        return hospital
   
    raise HTTPException(status_code=403, detail="You do not have permission to access this resource.")

def get_my_hospital(current_user: User, db: Session):
    hospital_id = None
    user_role = current_user.role.name
    if user_role == "Hospital_Admin":
        hospital_id = current_user.hospital.id
    elif user_role == "Receptionist":
        hospital_id = current_user.staff_profile.hospital_id
    elif user_role == "Doctor":
        if current_user.doctor_profile and current_user.doctor_profile.department:
            hospital_id = current_user.doctor_profile.department.hospital_id
    
    if not hospital_id:
        raise HTTPException(status_code=404, detail="Could not determine the hospital for this user.")

    hospital = db.query(Hospital).options(joinedload(Hospital.departments)).filter(Hospital.id == hospital_id).first()
    if not hospital:
        raise HTTPException(status_code=404, detail="Hospital details not found.")
    return hospital

def get_all_hospitals(db: Session, page: int, size: int):
    """
    Fetches all hospitals with pagination. Returns raw Hospital objects.
    """
    if page < 1:
        page = 1
   
    offset = (page - 1) * size
   
    total = db.query(Hospital).count()
    hospitals = db.query(Hospital).offset(offset).limit(size).all()
    total_pages = math.ceil(total / size)
   
    # Return raw data, let the route handle Pydantic conversion
    return PaginatedData(
        total=total,
        page=page,
        size=size,
        totalPages=total_pages,
        hospitals=hospitals
    )