from fastapi import Depends, HTTPException
from sqlalchemy.orm import Session, joinedload
from pydantic import BaseModel, EmailStr, Field
from datetime import datetime, date
from typing import Optional, List
from sqlalchemy import or_, String, cast
from db.db import get_db
from models.user_model import User
from models.role_model import Role
from models.patient_profile_model import PatientProfile
from services.user_service import get_password_hash
from services.hospital_service import generate_temporary_password
from utils.email_utils import send_welcome_email

class PatientCreate(BaseModel):
    # Core Info
    first_name: str
    last_name: str
    email: EmailStr
    phone_number: str
    client_type: str
    billing_type: str

    # Insurance Info (optional)
    insurer_name: Optional[str] = None
    member_id: Optional[str] = None
    group_id: Optional[str] = None
    subscriber_first_name: Optional[str] = None
    subscriber_last_name: Optional[str] = None
    subscriber_dob: Optional[date] = None
    subscriber_relationship_to_patient: Optional[str] = None

class PatientResponse(BaseModel):
    user_id: int
    profile_id: int
    email: EmailStr
    full_name: str
    status: bool
    assigned_doctor_id: Optional[int] = None

    class Config:
        from_attributes = True

def create_patient(db: Session, patient_data: PatientCreate, current_user: User):
    db.begin_nested()
    try:
        # --- FIX: Added 'Receptionist' to the allowed roles ---
        user_role = current_user.role.name
        if user_role == "Hospital_Admin":
            hospital_id = current_user.hospital.id
        elif user_role == "Doctor":
            hospital_id = current_user.doctor_profile.department.hospital_id
        elif user_role == "Receptionist":
            # Assumes a StaffProfile model is created and linked to the user
            if not current_user.staff_profile:
                raise HTTPException(status_code=403, detail="Staff profile not found for this user.")
            hospital_id = current_user.staff_profile.hospital_id
        else:
            raise HTTPException(status_code=403, detail="Your role cannot create patients.")
        # --- END FIX ---

        all_roles = db.query(Role).all()
        patient_role = next((role for role in all_roles if role.name == "Patient"), None)
        if not patient_role:
            raise HTTPException(status_code=500, detail="The 'Patient' role has not been configured.")

        if db.query(User).filter(User.email == patient_data.email).first():
            raise HTTPException(status_code=400, detail="A user with this email already exists.")

        temp_password = generate_temporary_password()
        new_user = User(
            email=patient_data.email,
            hashed_password=get_password_hash(temp_password),
            first_name=patient_data.first_name,
            last_name=patient_data.last_name,
            role_id=patient_role.id,
            created_at=str(datetime.utcnow()),
            updated_at=str(datetime.utcnow())
        )
        db.add(new_user)
        db.flush()

        is_active = False
        assigned_doctor_id = None
        if user_role == "Doctor":
            is_active = True
            assigned_doctor_id = current_user.id
        # Note: Patients created by Receptionist/Admin start as inactive (status=False)
        # and will need to be approved or assigned to a doctor.

        new_patient_profile = PatientProfile(
            user_id=new_user.id,
            hospital_id=hospital_id,
            status=is_active,
            assigned_doctor_id=assigned_doctor_id,
            client_type=patient_data.client_type,
            billing_type=patient_data.billing_type,
            insurer_name=patient_data.insurer_name,
            member_id=patient_data.member_id,
            group_id=patient_data.group_id,
            subscriber_first_name=patient_data.subscriber_first_name,
            subscriber_last_name=patient_data.subscriber_last_name,
            subscriber_dob=patient_data.subscriber_dob,
            subscriber_relationship_to_patient=patient_data.subscriber_relationship_to_patient
        )
        db.add(new_patient_profile)

        send_welcome_email(patient_data.email, temp_password)

        db.commit()
        
        return PatientResponse(
            user_id=new_user.id,
            profile_id=new_patient_profile.id,
            email=new_user.email,
            full_name=f"{new_user.first_name} {new_user.last_name}",
            status=new_patient_profile.status,
            assigned_doctor_id=new_patient_profile.assigned_doctor_id
        )

    except Exception as e:
        db.rollback()
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {str(e)}")

def get_all_patients(current_user: User, db: Session):
    user_role = current_user.role.name

    # --- FIX: Updated logic to correctly handle Receptionist/Staff ---
    if user_role in ["Hospital_Admin", "Receptionist", "Staff"]:
        if user_role == "Hospital_Admin":
            hospital_id = current_user.hospital.id
        else: # For Receptionist or other Staff
            if not current_user.staff_profile:
                 raise HTTPException(status_code=403, detail="Staff profile not found for this user.")
            hospital_id = current_user.staff_profile.hospital_id
        
        profiles = db.query(PatientProfile).filter(PatientProfile.hospital_id == hospital_id).options(joinedload(PatientProfile.user)).all()
    # --- END FIX ---
    elif user_role == "Doctor":
        profiles = db.query(PatientProfile).filter(PatientProfile.assigned_doctor_id == current_user.id).options(joinedload(PatientProfile.user)).all()
    else:
        return []

    return [
        PatientResponse(
            user_id=p.user.id,
            profile_id=p.id,
            email=p.user.email,
            full_name=f"{p.user.first_name} {p.user.last_name}",
            status=p.status,
            assigned_doctor_id=p.assigned_doctor_id
        ) for p in profiles
    ]

def search_patients(current_user, db, q: str, page: int = 1, limit: int = 10):
    # Load all patients for role
    query = db.query(PatientProfile).options(joinedload(PatientProfile.user))
    patients = query.all()

    # Filter in Python after decryption
    search_lower = q.lower()
    filtered = [
        {
            "user_id": p.user.id,
            "profile_id": p.id,
            "email": p.user.email,
            "full_name": f"{p.user.first_name} {p.user.last_name}".strip(),
            "status": p.status,
            "assigned_doctor_id": p.assigned_doctor_id
        }
        for p in patients
        if (search_lower in (p.user.first_name or "").lower() 
            or search_lower in (p.user.last_name or "").lower()
            or search_lower in (p.user.email or "").lower())
    ]

    # ✅ Apply pagination after filtering
    start = (page - 1) * limit
    end = start + limit
    paginated = filtered[start:end]

    return {
        "data": paginated,
        "total": len(filtered),
        "page": page,
        "hasMore": end < len(filtered)
    }