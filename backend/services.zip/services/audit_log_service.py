import os
import requests
import math
from fastapi import HTTPException
from pydantic import BaseModel, field_validator
from typing import List, Dict, Any, Optional
from datetime import datetime

class LogEntry(BaseModel):
    Timestamp: str
    Level: str
    MessageTemplate: Optional[str] = None
    RenderedMessage: Optional[str] = None
    Properties: Dict[str, Any] = {}

    class Config:
        from_attributes = True

    @field_validator('Properties', mode='before')
    @classmethod
    def convert_properties(cls, v):
        if isinstance(v, list):
            properties_dict = {}
            for prop in v:
                if isinstance(prop, dict) and "Name" in prop and "Value" in prop:
                    properties_dict[prop["Name"]] = prop["Value"]
            return properties_dict
        return v if isinstance(v, dict) else {}

class PaginatedLogResponse(BaseModel):
    total: int
    page: int
    size: int
    totalPages: int
    logs: List[LogEntry]

def get_logs_for_hospital(hospital_id: int, page: int, size: int):
    """
    Fetches paginated audit logs from the Seq API, filtered by a specific hospital_id.
    """
    seq_server_url = os.getenv("SEQ_SERVER_URL")
    seq_api_key = os.getenv("SEQ_API_KEY")

    if not seq_server_url or not seq_api_key:
        raise HTTPException(status_code=500, detail="Seq logging is not configured on the server.")

    headers = {"X-Seq-ApiKey": seq_api_key}
    api_url = f"{seq_server_url}/api/events"
    filter_query = f"HospitalId = {hospital_id}"

    try:
        # Step 1: Get the total count of matching events
        count_params = {"filter": filter_query, "query": "select count(*)"}
        count_response = requests.get(api_url, headers=headers, params=count_params)
        count_response.raise_for_status()
        total_count = count_response.json().get("Value", 0)
        total_pages = math.ceil(total_count / size) if total_count > 0 else 0

        # Step 2: Get the actual log events for the current page
        offset = (page - 1) * size
        event_params = {
            "filter": filter_query,
            "count": size,
            "skip": offset,
            "orderby": "@Timestamp desc"
        }
        event_response = requests.get(api_url, headers=headers, params=event_params)
        event_response.raise_for_status()
        
        data = event_response.json()
        if isinstance(data, dict):
            events_data = data.get("Events", [])
        elif isinstance(data, list):
            events_data = data
        else:
            events_data = []
        
        processed_events = [LogEntry.model_validate(event) for event in events_data]

        return PaginatedLogResponse(
            total=total_count,
            page=page,
            size=size,
            totalPages=total_pages,
            logs=processed_events
        )

    except requests.exceptions.RequestException as e:
        raise HTTPException(status_code=503, detail=f"Could not connect to the logging service: {str(e)}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"An error occurred while fetching logs: {str(e)}")
