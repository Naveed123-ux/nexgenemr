from fastapi import Depends, HTTPException
from sqlalchemy.orm import Session, joinedload
from pydantic import BaseModel
import math
from typing import List, Optional
from datetime import datetime, timedelta, date

from db.db import get_db
from models.user_model import User
from models.appointment_model import Appointment
from models.appointment_slot_model import AppointmentSlot
from models.availability_template_model import AvailabilityTemplate
from models.patient_profile_model import PatientProfile
from models.doctor_profile_model import DoctorProfile
from utils.google_calendar_utils import create_calendar_event
from utils.email_utils import send_appointment_confirmation_email

class AppointmentCreate(BaseModel):
    patient_profile_id: int
    appointment_slot_id: int
    is_telehealth: bool
    reason_for_visit: str

class AppointmentResponse(BaseModel):
    id: int
    patient_name: str
    doctor_name: str
    start_time: datetime
    end_time: datetime
    is_telehealth: bool
    status: str
    reason_for_visit: Optional[str] = None
    google_meet_link: Optional[str] = None

    class Config:
        from_attributes = True

class PaginatedAppointmentResponse(BaseModel):
    total: int
    page: int
    size: int
    totalPages: int
    appointments: List[AppointmentResponse]

def generate_appointment_slots(doctor_id: int, db: Session):
    templates = db.query(AvailabilityTemplate).filter(AvailabilityTemplate.doctor_user_id == doctor_id).all()
    if not templates:
        raise HTTPException(status_code=404, detail="Doctor has not set up an availability template.")

    db.query(AppointmentSlot).filter(
        AppointmentSlot.doctor_user_id == doctor_id,
        AppointmentSlot.start_time > datetime.utcnow()
    ).delete()

    today = date.today()
    for i in range(90):
        current_day = today + timedelta(days=i)
        day_name = current_day.strftime("%A")
        
        for template in templates:
            if template.day_of_week == day_name:
                start = datetime.combine(current_day, template.start_time)
                end = datetime.combine(current_day, template.end_time)
                
                while start + timedelta(minutes=template.slot_duration_minutes) <= end:
                    slot_end = start + timedelta(minutes=template.slot_duration_minutes)
                    new_slot = AppointmentSlot(
                        doctor_user_id=doctor_id,
                        start_time=start,
                        end_time=slot_end,
                        status='Available'
                    )
                    db.add(new_slot)
                    start = slot_end
    db.commit()
    return {"status": "success", "message": f"Generated appointment slots for doctor ID {doctor_id} for the next 90 days."}

def get_available_slots(doctor_id: int, start_date: date, db: Session):
    end_date = start_date + timedelta(days=1)
    return db.query(AppointmentSlot).filter(
        AppointmentSlot.doctor_user_id == doctor_id,
        AppointmentSlot.status == 'Available',
        AppointmentSlot.start_time >= datetime.combine(start_date, datetime.min.time()),
        AppointmentSlot.start_time < datetime.combine(end_date, datetime.min.time())
    ).all()

def create_appointment(db: Session, appt_data: AppointmentCreate, current_user: User):
    db.begin_nested()
    try:
        slot = db.query(AppointmentSlot).options(joinedload(AppointmentSlot.doctor)).filter(AppointmentSlot.id == appt_data.appointment_slot_id).first()
        if not slot or slot.status != 'Available':
            raise HTTPException(status_code=400, detail="This time slot is not available.")

        patient_profile = db.query(PatientProfile).options(joinedload(PatientProfile.user), joinedload(PatientProfile.hospital)).filter(PatientProfile.id == appt_data.patient_profile_id).first()
        if not patient_profile:
            raise HTTPException(status_code=404, detail="Patient not found.")

        doctor = slot.doctor
        meet_link = None

        if appt_data.is_telehealth:
            if not doctor.google_auth_token or not doctor.google_auth_token.refresh_token:
                raise HTTPException(status_code=400, detail="This doctor has not enabled telehealth by connecting their Google account.")
            
            meet_link = create_calendar_event(
                refresh_token=doctor.google_auth_token.refresh_token,
                summary=f"Appointment with {patient_profile.user.first_name} {patient_profile.user.last_name}",
                start_time=slot.start_time,
                end_time=slot.end_time,
                attendees=[patient_profile.user.email, doctor.email]
            )
            if not meet_link:
                raise HTTPException(status_code=500, detail="Failed to create Google Meet link.")

        slot.status = 'Booked'
        new_appointment = Appointment(
            patient_profile_id=appt_data.patient_profile_id,
            doctor_user_id=slot.doctor_user_id,
            appointment_slot_id=slot.id,
            is_telehealth=appt_data.is_telehealth,
            google_meet_link=meet_link,
            reason_for_visit=appt_data.reason_for_visit,
            status='Confirmed'
        )
        db.add(new_appointment)
        db.flush()

        patient_name = f"{patient_profile.user.first_name} {patient_profile.user.last_name}"
        doctor_name = f"Dr. {doctor.first_name} {doctor.last_name}"
        appointment_time_str = slot.start_time.strftime("%A, %B %d, %Y at %I:%M %p")
        
        send_appointment_confirmation_email(
            recipient_email=patient_profile.user.email, patient_name=patient_name, doctor_name=doctor_name,
            appointment_time=appointment_time_str, is_telehealth=appt_data.is_telehealth,
            meet_link=meet_link, hospital_address=patient_profile.hospital.address
        )
        send_appointment_confirmation_email(
            recipient_email=doctor.email, patient_name=patient_name, doctor_name=doctor_name,
            appointment_time=appointment_time_str, is_telehealth=appt_data.is_telehealth,
            meet_link=meet_link, hospital_address=patient_profile.hospital.address
        )

        db.commit()

        return AppointmentResponse(
            id=new_appointment.id,
            patient_name=patient_name,
            doctor_name=doctor_name,
            start_time=slot.start_time,
            end_time=slot.end_time,
            is_telehealth=new_appointment.is_telehealth,
            status=new_appointment.status,
            google_meet_link=new_appointment.google_meet_link
        )

    except Exception as e:
        db.rollback()
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=f"An unexpected error occurred: {str(e)}")

def get_appointments(
    db: Session, 
    current_user: User, 
    page: int, 
    size: int, 
    target_date: date, 
    search_query: Optional[str]
):
    base_query = db.query(Appointment).options(
        joinedload(Appointment.slot),
        joinedload(Appointment.patient).joinedload(PatientProfile.user),
        joinedload(Appointment.doctor).joinedload(User.doctor_profile).joinedload(DoctorProfile.department)
    ).join(Appointment.slot)

    user_role = current_user.role.name
    if user_role in ["Hospital_Admin", "Receptionist"]:
        hospital_id = current_user.hospital.id if user_role == "Hospital_Admin" else current_user.staff_profile.hospital_id
        base_query = base_query.join(Appointment.patient).filter(PatientProfile.hospital_id == hospital_id)
    elif user_role == "Doctor":
        base_query = base_query.filter(Appointment.doctor_user_id == current_user.id)
    
    start_of_day = datetime.combine(target_date, datetime.min.time())
    end_of_day = datetime.combine(target_date, datetime.max.time())
    base_query = base_query.filter(AppointmentSlot.start_time.between(start_of_day, end_of_day))

    all_appointments = base_query.all()

    filtered_appointments = []
    if search_query:
        search_lower = search_query.lower()
        for appt in all_appointments:
            patient_name = f"{appt.patient.user.first_name} {appt.patient.user.last_name}".lower()
            doctor_name = f"{appt.doctor.first_name} {appt.doctor.last_name}".lower()
            if search_lower in patient_name or search_lower in doctor_name:
                filtered_appointments.append(appt)
    else:
        filtered_appointments = all_appointments

    total = len(filtered_appointments)
    total_pages = math.ceil(total / size) if total > 0 else 0
    offset = (page - 1) * size
    paginated_list = filtered_appointments[offset : offset + size]

    response_list = []
    for appt in paginated_list:
        department_name = "N/A"
        if appt.doctor.doctor_profile and appt.doctor.doctor_profile.department:
            department_name = appt.doctor.doctor_profile.department.name
        
        doctor_name_with_dept = f"Dr. {appt.doctor.first_name} {appt.doctor.last_name} ({department_name})"
        
        # --- FIX: Added the missing reason_for_visit field ---
        response_list.append(
            AppointmentResponse(
                id=appt.id,
                patient_name=f"{appt.patient.user.first_name} {appt.patient.user.last_name}",
                doctor_name=doctor_name_with_dept,
                start_time=appt.slot.start_time,
                end_time=appt.slot.end_time,
                is_telehealth=appt.is_telehealth,
                status=appt.status,
                google_meet_link=appt.google_meet_link,
                reason_for_visit=appt.reason_for_visit
            )
        )
        # --- END FIX ---

    return PaginatedAppointmentResponse(
        total=total,
        page=page,
        size=size,
        totalPages=total_pages,
        appointments=response_list
    )



def get_doctor_weekly_appointments(
    db: Session,
    current_user: User,
    start_date: date
):
    if not current_user.role or current_user.role.name != "Doctor":
        raise HTTPException(status_code=403, detail="Only doctors can access this endpoint.")

    # ✅ Adjust week calculation:
    # - Normal: Monday–Sunday
    # - If given date is Sunday, shift to NEXT week (Mon–Sun)
    if start_date.weekday() == 6:  # Sunday
        start_of_week = start_date + timedelta(days=1)  # Next Monday
    else:
        start_of_week = start_date - timedelta(days=start_date.weekday())  # Current Monday

    end_of_week = start_of_week + timedelta(days=6)  # Sunday

    # ✅ Query only appointments inside this week
    appointments = db.query(Appointment).options(
        joinedload(Appointment.slot),
        joinedload(Appointment.patient).joinedload(PatientProfile.user),
    ).filter(
        Appointment.doctor_user_id == current_user.id,
        AppointmentSlot.start_time >= datetime.combine(start_of_week, datetime.min.time()),
        AppointmentSlot.start_time <= datetime.combine(end_of_week, datetime.max.time())
    ).all()

    # ✅ Group appointments by day
    week_schedule = {}
    for i in range(7):  # Ensure all days exist in response
        day = start_of_week + timedelta(days=i)
        week_schedule[day] = []

    for appt in appointments:
        appt_date = appt.slot.start_time.date()
        if appt_date in week_schedule:  # Ensure it fits into this week
            week_schedule[appt_date].append(
                AppointmentResponse(
                    id=appt.id,
                    patient_name=f"{appt.patient.user.first_name} {appt.patient.user.last_name}",
                    doctor_name=f"Dr. {current_user.first_name} {current_user.last_name}",
                    start_time=appt.slot.start_time,
                    end_time=appt.slot.end_time,
                    is_telehealth=appt.is_telehealth,
                    status=appt.status,
                    google_meet_link=appt.google_meet_link,
                    reason_for_visit=appt.reason_for_visit
                )
            )

    # ✅ Convert keys to str for JSON response
    appointments_by_day = {
        str(day): week_schedule[day] for day in sorted(week_schedule.keys())
    }

    return {
        "doctor_id": current_user.id,
        "doctor_name": f"Dr. {current_user.first_name} {current_user.last_name}",
        "week_start": start_of_week,
        "week_end": end_of_week,
        "appointments_by_day": appointments_by_day
    }
