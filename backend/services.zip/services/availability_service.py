from fastapi import Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel, Field
from typing import List
from datetime import time

from db.db import get_db
from models.user_model import User
from models.availability_template_model import AvailabilityTemplate

class AvailabilitySlot(BaseModel):
    day_of_week: str
    start_time: time
    end_time: time
    slot_duration_minutes: int = 20
    is_telemedicine: bool = False

class AvailabilityTemplateCreate(BaseModel):
    slots: List[AvailabilitySlot]

class AvailabilityTemplateResponse(BaseModel):
    slots: List[AvailabilitySlot]

    class Config:
        from_attributes = True

def set_availability_template(
    db: Session,
    template_data: AvailabilityTemplateCreate,
    current_user: User # This is the Doctor
):
    doctor_id = current_user.id

    # Start a transaction
    db.begin_nested()
    try:
        # First, delete all existing template entries for this doctor
        db.query(AvailabilityTemplate).filter(AvailabilityTemplate.doctor_user_id == doctor_id).delete()

        # Now, create the new template entries from the request
        for slot in template_data.slots:
            if slot.start_time >= slot.end_time:
                raise HTTPException(status_code=400, detail=f"Start time must be before end time for {slot.day_of_week}.")

            new_template_entry = AvailabilityTemplate(
                doctor_user_id=doctor_id,
                day_of_week=slot.day_of_week,
                start_time=slot.start_time,
                end_time=slot.end_time,
                slot_duration_minutes=slot.slot_duration_minutes,
                is_telemedicine=slot.is_telemedicine
            )
            db.add(new_template_entry)
        
        db.commit()
    except Exception as e:
        db.rollback()
        if isinstance(e, HTTPException):
            raise e
        raise HTTPException(status_code=500, detail=f"An error occurred while setting availability: {str(e)}")

    return get_availability_template(current_user, db)


def get_availability_template(current_user: User, db: Session):
    doctor_id = current_user.id
    
    template_entries = db.query(AvailabilityTemplate).filter(AvailabilityTemplate.doctor_user_id == doctor_id).all()
    
    # Format the response
    response_slots = [
        AvailabilitySlot(
            day_of_week=entry.day_of_week,
            start_time=entry.start_time,
            end_time=entry.end_time,
            slot_duration_minutes=entry.slot_duration_minutes,
            is_telemedicine=entry.is_telemedicine
        ) for entry in template_entries
    ]
    
    return AvailabilityTemplateResponse(slots=response_slots)
